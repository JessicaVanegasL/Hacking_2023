# two-sum

## Objetivo

Additional details will be available after launching your challenge instance.

## Hints



## Solución

``` 
┌──(kali㉿kali)-[~/Documents/PicoCTF]
└─$ bc                          
bc 1.07.1
Copyright 1991-1994, 1997, 1998, 2000, 2004, 2006, 2008, 2012-2017 Free Software Foundation, Inc.
This is free software with ABSOLUTELY NO WARRANTY.
For details type `warranty'. 
2^31
2147483647

┌──(kali㉿kali)-[~/Documents/PicoCTF]
└─$ nc saturn.picoctf.net 62799
n1 > n1 + n2 OR n2 > n1 + n2 
What two positive numbers can make this possible: 
2147483647
47
You entered 2147483647 and 47
You have an integer overflow
YOUR FLAG IS: picoCTF{Tw0_Sum_Integer_Bu773R_0v3rfl0w_bc0adfd1}
```

## Flag

picoCTF{Tw0_Sum_Integer_Bu773R_0v3rfl0w_bc0adfd1}

## Notas adicionales

## Referencias
