# Bit-O-Asm-2

## Objetivo


## Hints



## Solución

```              
```


## Flag

picoCTF{}

## Notas adicionales


## Referencias

[rsa](https://simple.wikipedia.org/wiki/RSA_algorithm)