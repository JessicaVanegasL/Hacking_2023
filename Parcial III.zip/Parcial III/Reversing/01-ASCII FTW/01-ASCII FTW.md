# ASCII FTW

## Objetivo

This program has constructed the flag using hex ascii values. Identify the flag text by disassembling the program.You can download the file from [here](https://artifacts.picoctf.net/c/508/asciiftw).

## Hints

- The combined range of hex-ascii for English alphabets and numerical digits is from 30 to 7A.
- Online hex-ascii converters can be helpful.

## Solución

```              
```


## Flag

picoCTF{}

## Notas adicionales


## Referencias

[rsa](https://simple.wikipedia.org/wiki/RSA_algorithm)