# GDB baby step 1

## Objetivo


## Hints



## Solución

```              
```


## Flag

picoCTF{}

## Notas adicionales


## Referencias

[rsa](https://simple.wikipedia.org/wiki/RSA_algorithm)